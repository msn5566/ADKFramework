```markdown
## Changelog

- **Title:** Changed "Employee Management Microservice" to "Employee and student Management Microservice".
- **Metadata:** Changed `GitHub-Branch` to `checkout_branch`.
```